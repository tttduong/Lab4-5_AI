# lab4&5_AI
***How to Compile and Run the Code***

# Prerequisites: Python 3.x  (above 3.0 is stable) 

# Steps to Compile and Run

1. Clone the repository

git clone https://github.com/tttduong/Lab4-5_AI

# Recommend using virtual environments to set up library
    (*) For Linux/macOS
        python3 -m venv venv
        source venv/bin/activate
    (*) For Windows
        python -m venv venv
        venv\Scripts\activate
------------------


----------------------------------------------------------------
Exercise 2:
in the search.py: 

comment line 68-95 (Exercise 3)
uncomment line 37-60 (Exercise 2)

then run the command lines in turn: 
python sudoku.py --inputFile data/euler.txt	
python sudoku.py --inputFile data/magictour.txt
----------------------------------------------------------------
Exercise 3: 
in the search.py: 

uncomment line 68-95 (Exercise 3)
comment line 37-60 (Exercise 2)

then run the command lines in turn: 
python sudoku.py --inputFile data/euler.txt	
python sudoku.py --inputFile data/magictour.txt
